from fastapi import FastAPI
from app.routers import preflight, views, sketch2d, register, plan, build, export

app = FastAPI(title="Core API TZ", version="0.1.0")

app.include_router(preflight.router)
app.include_router(views.router)
app.include_router(sketch2d.router)
app.include_router(register.router)
app.include_router(plan.router)
app.include_router(build.router)
app.include_router(export.router)
