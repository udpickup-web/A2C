# Core API (TZ v1)

FastAPI проект с эндпоинтами: `/preflight`, `/views`, `/sketch2d`, `/register`, `/plan`, `/build`, `/export/openapi`.

## Быстрый старт (Windows CMD, Python 3.11)

```bat
cd %~dp0
py -3.11 -m venv .venv
.venv\Scripts\python -m pip install --upgrade pip
.venv\Scripts\pip install -r requirements.txt
.venv\Scripts\uvicorn app.main:app --host 127.0.0.1 --port 8001 --reload
```

Открой в браузере: http://127.0.0.1:8001/docs

## Генерация OpenAPI в файл

```bat
.venv\Scripts\python generate_openapi.py
```

Сгенерируется `openapi.json` в корне проекта.

## Примеры запросов

В папке `samples/` лежат валидные JSON для `/preflight`, `/views`, `/plan`, `/build`.

```bat
.venv\Scripts\python example_client.py
```

## Контракты

Исходные схемы: `contracts/*.schema.json`.
